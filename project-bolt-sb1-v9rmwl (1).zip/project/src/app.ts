import { Application } from '@nativescript/core';
import { install } from '@nativescript/react';

install();

Application.run({ moduleName: 'app-root' });